const blogs = [
    { id: '1', title: 'React Basics', content: 'Learn the basics of React and how to create components, props, and states.' },
    { id: '2', title: 'React Router Dom', content: 'Master routing with react-router-dom to create single-page applications.' },
    { id: '3', title: 'React Hooks', content: 'Understand how to use useState, useEffect, and custom hooks in your React apps.' },
    { id: '4', title: 'React Makes', content: 'Good React Makes. ' },
    { id: '5', title: 'React', content: 'Frontend Technology used for frontend designs. ' },
  ];
  
  export default blogs;
  